
package servlets;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class ScheduleAppointmentServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
        int patientId = Integer.parseInt(req.getParameter("patient_id"));
        int doctorId = Integer.parseInt(req.getParameter("doctor_id"));
        int surgeryId = Integer.parseInt(req.getParameter("surgery_id"));
        int roomId = Integer.parseInt(req.getParameter("room_id"));
        String date = req.getParameter("date");
        String time = req.getParameter("time");
        String status = req.getParameter("status");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/surgery_db", "root", "");
            PreparedStatement ps = con.prepareStatement("INSERT INTO appointments (patient_id, doctor_id, surgery_id, room_id, date, time, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
            ps.setInt(1, patientId);
            ps.setInt(2, doctorId);
            ps.setInt(3, surgeryId);
            ps.setInt(4, roomId);
            ps.setString(5, date);
            ps.setString(6, time);
            ps.setString(7, status);
            ps.executeUpdate();
            res.sendRedirect("view_appointments.jsp");
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
