
package servlets;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class AddPatientServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
        String fname = req.getParameter("first_name");
        String lname = req.getParameter("last_name");
        String dob = req.getParameter("dob");
        String gender = req.getParameter("gender");
        String contact = req.getParameter("contact_number");
        String email = req.getParameter("email");
        String address = req.getParameter("address");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/surgery_db", "root", "");
            PreparedStatement ps = con.prepareStatement("INSERT INTO patients (first_name, last_name, dob, gender, contact_number, email, address) VALUES (?, ?, ?, ?, ?, ?, ?)");
            ps.setString(1, fname);
            ps.setString(2, lname);
            ps.setString(3, dob);
            ps.setString(4, gender);
            ps.setString(5, contact);
            ps.setString(6, email);
            ps.setString(7, address);
            ps.executeUpdate();
            res.sendRedirect("view_patients.jsp");
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
