SPORTS FACILITY BOOKING WEB APPLICATION
---------------------------------------

REQUIREMENTS
------------
Python 3.10 or later
Flask 3.1 or later

INSTALLATION
------------
1. Open Command Prompt or Terminal.
2. Navigate to this project folder:
      cd "C:\Users\uddin\OneDrive\Documents\University 3rd Year\CS6P05 Project\sports_booking_flask"
3. Install required packages:
      pip install -r requirements.txt

RUNNING THE APPLICATION
-----------------------
1. Start the application:
      python app.py
2. Open your browser and go to:
      http://127.0.0.1:5000

LOGIN DETAILS
-------------
Admin:
   email: admin@example.com
   password: admin123

Users:
   Register new accounts via the Register page.

FEATURES
--------
- Register / Login system using SQLite
- Role-based access (Admin / Member)
- Admin:
    * Manage Facilities (Add, Delete)
    * View all Bookings
- Member:
    * View Facilities
    * Book Facilities (date & time)
    * View My Bookings
- Prevents double booking for same facility and time-slot
- Simple custom CSS styling
- Runs entirely locally (no internet dependency)

FILES
-----
app.py
templates/        -> all HTML templates
static/style.css  -> styling
database/sports_booking.db
requirements.txt
README.txt

AUTHOR
------
Muhammod Belal Uddin
Student ID: 23032697
Course: BSc Computer Science
Module: CS6P05
Supervisor: Dr Qicheng Yu