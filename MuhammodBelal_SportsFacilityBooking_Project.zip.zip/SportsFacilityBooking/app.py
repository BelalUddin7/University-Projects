import csv
from io import StringIO
from flask import make_response
from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
import os
from functools import wraps
from datetime import date, datetime, timedelta
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-secret-key-change-this")
app.permanent_session_lifetime = timedelta(minutes=30)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE_DIR = os.path.join(BASE_DIR, "database")
DB_PATH = os.path.join(DATABASE_DIR, "sports_booking.db")

os.makedirs(DATABASE_DIR, exist_ok=True)


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def is_hashed_password(password):
    return password.startswith("scrypt:") or password.startswith("pbkdf2:")


def password_is_valid(stored_password, entered_password):
    if is_hashed_password(stored_password):
        return check_password_hash(stored_password, entered_password)
    return stored_password == entered_password


def valid_time_slot(time_text):
    """
    Allow booking times only between 06:00 and 22:00.
    """
    try:
        parsed = datetime.strptime(time_text, "%H:%M").time()
        opening = datetime.strptime("06:00", "%H:%M").time()
        closing = datetime.strptime("22:00", "%H:%M").time()
        return opening <= parsed <= closing
    except ValueError:
        return False

def get_facility_image(name):
    name = name.lower().strip()

    if "gym" in name:
        return "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&w=900&q=80"
    elif "sauna" in name:
        return "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?auto=format&fit=crop&w=900&q=80"
    elif "football" in name or "pitch" in name:
        return "https://images.unsplash.com/photo-1574629810360-7efbbe195018?auto=format&fit=crop&w=900&q=80"
    elif "badminton" in name:
        return "https://images.unsplash.com/photo-1613918431703-aa50851d4b30?auto=format&fit=crop&w=900&q=80"
    else:
        return "https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&w=900&q=80"

def init_db():
    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'member'
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS facilities(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT NOT NULL
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS bookings(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            facility_id INTEGER NOT NULL,
            date TEXT NOT NULL,
            time_slot TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY(facility_id) REFERENCES facilities(id) ON DELETE CASCADE,
            UNIQUE(facility_id, date, time_slot)
        )
    """)

    admin = cur.execute(
        "SELECT * FROM users WHERE email = ?",
        ("admin@example.com",)
    ).fetchone()

    hashed_admin_password = generate_password_hash("admin123")

    if admin is None:
        cur.execute("""
            INSERT INTO users (name, email, password, role)
            VALUES (?, ?, ?, ?)
        """, (
            "Admin",
            "admin@example.com",
            hashed_admin_password,
            "admin"
        ))
    else:
        cur.execute("""
            UPDATE users
            SET name = ?, password = ?, role = ?
            WHERE email = ?
        """, (
            "Admin",
            hashed_admin_password,
            "admin",
            "admin@example.com"
        ))

    conn.commit()
    conn.close()


init_db()


@app.before_request
def make_session_permanent():
    session.permanent = True


def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "user" not in session:
            flash("Please log in to continue.", "error")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapper


def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        user = session.get("user")
        if not user:
            flash("Please log in first.", "error")
            return redirect(url_for("login"))
        if user.get("role") != "admin":
            flash("Access denied. Admin only.", "error")
            return redirect(url_for("dashboard"))
        return f(*args, **kwargs)
    return wrapper


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "").strip()

        if not name or not email or not password:
            return render_template("register.html", error="All fields are required.")

        if len(password) < 6:
            return render_template("register.html", error="Password must be at least 6 characters long.")

        conn = get_db()
        try:
            conn.execute("""
                INSERT INTO users (name, email, password, role)
                VALUES (?, ?, ?, ?)
            """, (name, email, generate_password_hash(password), "member"))
            conn.commit()
            flash("Your account has been created successfully. Please log in.", "success")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            return render_template("register.html", error="That email address is already registered.")
        finally:
            conn.close()

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "").strip()

        conn = get_db()
        user = conn.execute(
            "SELECT * FROM users WHERE email = ?",
            (email,)
        ).fetchone()

        if user and password_is_valid(user["password"], password):
            session["user"] = {
                "id": user["id"],
                "name": user["name"],
                "email": user["email"],
                "role": user["role"]
            }
            conn.close()
            flash(f"Welcome back, {user['name']}!", "success")
            return redirect(url_for("dashboard"))

        conn.close()
        return render_template("login.html", error="Invalid email or password.")

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out successfully.", "info")
    return redirect(url_for("home"))


@app.route("/dashboard")
@login_required
def dashboard():
    user = session["user"]
    conn = get_db()

    booking_count = conn.execute(
        "SELECT COUNT(*) AS total FROM bookings WHERE user_id = ?",
        (user["id"],)
    ).fetchone()["total"]

    facility_count = conn.execute(
        "SELECT COUNT(*) AS total FROM facilities"
    ).fetchone()["total"]

    total_users = 0
    total_bookings = 0

    if user["role"] == "admin":
        total_users = conn.execute(
            "SELECT COUNT(*) AS total FROM users"
        ).fetchone()["total"]

        total_bookings = conn.execute(
            "SELECT COUNT(*) AS total FROM bookings"
        ).fetchone()["total"]

    conn.close()

    return render_template(
        "dashboard.html",
        user=user,
        booking_count=booking_count,
        facility_count=facility_count,
        total_users=total_users,
        total_bookings=total_bookings
    )


@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    user = session["user"]
    conn = get_db()

    current_user = conn.execute(
        "SELECT * FROM users WHERE id = ?",
        (user["id"],)
    ).fetchone()

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "").strip()

        if not name or not email:
            conn.close()
            flash("Name and email cannot be empty.", "error")
            return redirect(url_for("profile"))

        try:
            if password:
                hashed_password = generate_password_hash(password)

                conn.execute("""
                    UPDATE users
                    SET name = ?, email = ?, password = ?
                    WHERE id = ?
                """, (name, email, hashed_password, user["id"]))
            else:
                conn.execute("""
                    UPDATE users
                    SET name = ?, email = ?
                    WHERE id = ?
                """, (name, email, user["id"]))

            conn.commit()

            session["user"]["name"] = name
            session["user"]["email"] = email

            flash("Profile updated successfully.", "success")

        except sqlite3.IntegrityError:
            flash("That email address is already in use.", "error")

        conn.close()
        return redirect(url_for("profile"))

    conn.close()
    return render_template(
        "profile.html",
        user=current_user
    )


@app.route("/facilities")
@login_required
def facilities():
    search = request.args.get("search", "").strip()

    conn = get_db()

    if search:
        facility_rows = conn.execute("""
            SELECT * FROM facilities
            WHERE name LIKE ? OR description LIKE ?
            ORDER BY name
        """, (f"%{search}%", f"%{search}%")).fetchall()
    else:
        facility_rows = conn.execute("""
            SELECT * FROM facilities
            ORDER BY name
        """).fetchall()

    conn.close()

    facilities_with_images = []
    for facility in facility_rows:
        facility_dict = dict(facility)
        facility_dict["image"] = get_facility_image(facility["name"])
        facilities_with_images.append(facility_dict)

    return render_template(
        "facilities.html",
        facilities=facilities_with_images,
        user=session["user"],
        search=search
    )

@app.route("/bookings")
@login_required
def my_bookings():
    user = session["user"]
    conn = get_db()
    booking_rows = conn.execute("""
        SELECT
            b.id,
            f.name AS facility_name,
            b.date,
            b.time_slot
        FROM bookings b
        JOIN facilities f ON b.facility_id = f.id
        WHERE b.user_id = ?
        ORDER BY b.date, b.time_slot
    """, (user["id"],)).fetchall()
    conn.close()

    bookings_with_status = []
    today = date.today()

    for booking in booking_rows:
        booking_dict = dict(booking)
        booking_date = datetime.strptime(booking["date"], "%Y-%m-%d").date()

        if booking_date < today:
            booking_dict["status"] = "Completed"
        else:
            booking_dict["status"] = "Upcoming"

        bookings_with_status.append(booking_dict)

    return render_template("bookings.html", bookings=bookings_with_status, user=user)


@app.route("/booking/cancel/<int:booking_id>")
@login_required
def cancel_booking(booking_id):
    user = session["user"]
    conn = get_db()

    booking = conn.execute("""
        SELECT * FROM bookings
        WHERE id = ? AND user_id = ?
    """, (booking_id, user["id"])).fetchone()

    if booking is None:
        conn.close()
        flash("Booking not found, or you do not have permission to cancel it.", "error")
        return redirect(url_for("my_bookings"))

    conn.execute("DELETE FROM bookings WHERE id = ?", (booking_id,))
    conn.commit()
    conn.close()

    flash("Booking cancelled successfully. You can now make a new booking.", "success")
    return redirect(url_for("my_bookings"))


@app.route("/book/<int:facility_id>", methods=["GET", "POST"])
@login_required
def book_facility(facility_id):
    user = session["user"]
    conn = get_db()

    facility = conn.execute(
        "SELECT * FROM facilities WHERE id = ?",
        (facility_id,)
    ).fetchone()

    if facility is None:
        conn.close()
        flash("Facility not found.", "error")
        return redirect(url_for("facilities"))

    if request.method == "POST":
        booking_date = request.form.get("date", "").strip()
        time_slot = request.form.get("time_slot", "").strip()

        if not booking_date or not time_slot:
            conn.close()
            return render_template(
                "book_facility.html",
                facility=facility,
                user=user,
                error="Please choose both a booking date and a time."
            )

        if booking_date < str(date.today()):
            conn.close()
            return render_template(
                "book_facility.html",
                facility=facility,
                user=user,
                error="You cannot book a past date."
            )

        if not valid_time_slot(time_slot):
            conn.close()
            return render_template(
                "book_facility.html",
                facility=facility,
                user=user,
                error="Bookings must be between 06:00 and 22:00."
            )

        try:
            conn.execute("""
                INSERT INTO bookings (user_id, facility_id, date, time_slot)
                VALUES (?, ?, ?, ?)
            """, (user["id"], facility_id, booking_date, time_slot))
            conn.commit()
            message = "Your booking has been confirmed successfully."
            success = True
        except sqlite3.IntegrityError:
            message = "That time slot is already booked for this facility. Please choose another one."
            success = False

        conn.close()
        return render_template(
            "book_confirmation.html",
            facility=facility,
            message=message,
            success=success,
            user=user,
            booking_date=booking_date,
            time_slot=time_slot
        )

    conn.close()
    return render_template("book_facility.html", facility=facility, user=user)


@app.route("/admin/facilities", methods=["GET", "POST"])
@admin_required
def manage_facilities():
    conn = get_db()

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        description = request.form.get("description", "").strip()

        if not name or not description:
            flash("Both facility name and description are required.", "error")
        else:
            conn.execute(
                "INSERT INTO facilities (name, description) VALUES (?, ?)",
                (name, description)
            )
            conn.commit()
            flash("Facility added successfully.", "success")

    facility_rows = conn.execute(
        "SELECT * FROM facilities ORDER BY id DESC"
    ).fetchall()
    conn.close()

    return render_template(
        "admin_facilities.html",
        facilities=facility_rows,
        user=session["user"]
    )


@app.route("/admin/facilities/edit/<int:fid>", methods=["GET", "POST"])
@admin_required
def edit_facility(fid):
    conn = get_db()
    facility = conn.execute(
        "SELECT * FROM facilities WHERE id = ?",
        (fid,)
    ).fetchone()

    if facility is None:
        conn.close()
        flash("Facility not found.", "error")
        return redirect(url_for("manage_facilities"))

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        description = request.form.get("description", "").strip()

        if not name or not description:
            conn.close()
            return render_template(
                "admin_edit_facility.html",
                facility=facility,
                error="Both facility name and description are required.",
                user=session["user"]
            )

        conn.execute("""
            UPDATE facilities
            SET name = ?, description = ?
            WHERE id = ?
        """, (name, description, fid))
        conn.commit()
        conn.close()

        flash("Facility updated successfully.", "success")
        return redirect(url_for("manage_facilities"))

    conn.close()
    return render_template(
        "admin_edit_facility.html",
        facility=facility,
        user=session["user"]
    )


@app.route("/admin/facilities/delete/<int:fid>")
@admin_required
def delete_facility(fid):
    conn = get_db()

    booking_count = conn.execute(
        "SELECT COUNT(*) AS total FROM bookings WHERE facility_id = ?",
        (fid,)
    ).fetchone()["total"]

    if booking_count > 0:
        flash("This facility cannot be deleted because it still has bookings.", "error")
    else:
        conn.execute("DELETE FROM facilities WHERE id = ?", (fid,))
        conn.commit()
        flash("Facility deleted successfully.", "success")

    conn.close()
    return redirect(url_for("manage_facilities"))


@app.route("/admin/bookings")
@admin_required
def admin_bookings():
    conn = get_db()
    booking_rows = conn.execute("""
        SELECT
            b.id,
            u.name AS user_name,
            u.email AS user_email,
            f.name AS facility_name,
            b.date,
            b.time_slot
        FROM bookings b
        JOIN users u ON b.user_id = u.id
        JOIN facilities f ON b.facility_id = f.id
        ORDER BY b.date, b.time_slot
    """).fetchall()
    conn.close()

    bookings_with_status = []
    today = date.today()

    for booking in booking_rows:
        booking_dict = dict(booking)
        booking_date = datetime.strptime(booking["date"], "%Y-%m-%d").date()

        if booking_date < today:
            booking_dict["status"] = "Completed"
        else:
            booking_dict["status"] = "Upcoming"

        bookings_with_status.append(booking_dict)

    return render_template(
        "admin_bookings.html",
        bookings=bookings_with_status,
        user=session["user"]
    )

@app.route("/admin/bookings/export")
@admin_required
def export_bookings_csv():
    conn = get_db()
    booking_rows = conn.execute("""
        SELECT
            b.id,
            u.name AS user_name,
            u.email AS user_email,
            f.name AS facility_name,
            b.date,
            b.time_slot
        FROM bookings b
        JOIN users u ON b.user_id = u.id
        JOIN facilities f ON b.facility_id = f.id
        ORDER BY b.date, b.time_slot
    """).fetchall()
    conn.close()

    output = StringIO()
    writer = csv.writer(output)

    writer.writerow([
        "Booking ID",
        "User Name",
        "User Email",
        "Facility",
        "Date",
        "Time Slot"
    ])

    for booking in booking_rows:
        writer.writerow([
            booking["id"],
            booking["user_name"],
            booking["user_email"],
            booking["facility_name"],
            booking["date"],
            booking["time_slot"]
        ])

    response = make_response(output.getvalue())
    response.headers["Content-Disposition"] = "attachment; filename=bookings_report.csv"
    response.headers["Content-type"] = "text/csv"
    return response

@app.route("/admin/bookings/delete/<int:booking_id>")
@admin_required
def admin_delete_booking(booking_id):
    conn = get_db()

    booking = conn.execute(
        "SELECT * FROM bookings WHERE id = ?",
        (booking_id,)
    ).fetchone()

    if booking is None:
        conn.close()
        flash("Booking not found.", "error")
        return redirect(url_for("admin_bookings"))

    conn.execute("DELETE FROM bookings WHERE id = ?", (booking_id,))
    conn.commit()
    conn.close()

    flash("Booking deleted successfully.", "success")
    return redirect(url_for("admin_bookings"))


@app.route("/admin/users")
@admin_required
def admin_users():
    conn = get_db()
    users = conn.execute("""
        SELECT
            u.id,
            u.name,
            u.email,
            u.role,
            COUNT(b.id) AS booking_total
        FROM users u
        LEFT JOIN bookings b ON u.id = b.user_id
        GROUP BY u.id, u.name, u.email, u.role
        ORDER BY u.role DESC, u.name ASC
    """).fetchall()
    conn.close()

    return render_template(
        "admin_users.html",
        users=users,
        user=session["user"]
    )


@app.route("/admin/users/delete/<int:user_id>")
@admin_required
def delete_user(user_id):
    current_user = session["user"]

    if user_id == current_user["id"]:
        flash("You cannot delete your own admin account.", "error")
        return redirect(url_for("admin_users"))

    conn = get_db()
    user_to_delete = conn.execute(
        "SELECT * FROM users WHERE id = ?",
        (user_id,)
    ).fetchone()

    if user_to_delete is None:
        conn.close()
        flash("User not found.", "error")
        return redirect(url_for("admin_users"))

    conn.execute("DELETE FROM users WHERE id = ?", (user_id,))
    conn.commit()
    conn.close()

    flash("User deleted successfully.", "success")
    return redirect(url_for("admin_users"))


if __name__ == "__main__":
    app.run(debug=True)